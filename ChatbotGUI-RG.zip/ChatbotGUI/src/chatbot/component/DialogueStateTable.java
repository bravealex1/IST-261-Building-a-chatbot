package chatbot.component;

import java.util.Hashtable;
import java.util.List;
import java.util.Random;

public class DialogueStateTable {

	public DialogueStateTable() {
		
	}
	
	//===== "Method modified for Response Generation assignment" Begins ===== 
	public static String execute(String dialogueStateName, List<Hashtable<String, String>> slotHistory, String nowInputText) {
	//===== "Method modified for Response Generation assignment" Ends ===== 
		
		String response = "I am not sure. Could you say more?";
		
		switch (dialogueStateName) {
		
			case "CHIT-CHAT":
				//===== "Method modified for Response Generation assignment" Begins =====
				//Example 1: Respond conditioned on user's message
				response = getChitChatResponse(nowInputText);
				//response = "[CHIT-CHAT RESPONSE]";
				//===== "Method modified for Response Generation assignment" Ends ===== 
			break;
			
			case "GREETING":
				//===== "Method modified for Response Generation assignment" Begins =====
				//Example 2: Randomly pick a response from a dictionary
				String[] greetingDictionary = {
						"Hello! How can I help you?",
						"What can I do for you today?",
						"How are you today? I am TaskBot."
				};
				Random r = new Random();        
		      	int randomNumber = r.nextInt(greetingDictionary.length);
		      	response = greetingDictionary[randomNumber];
		      	//===== "Method modified for Response Generation assignment" Ends ===== 
			break;
			
			/*
		 	case "START-STATE":
		 		response = "Hello! How can I help you?";
		 	break;
			*/
		
			//Dialogue States that are independent from domains/intents 
		
        	case "ASK-LOCATION":
        		//===== "Method modified for Response Generation assignment" Begins =====
				//Example 3: Randomly pick a response from a dictionary (for location)
				String[] locationQuestionDictionary = {
						"Where are you?",
						"What's your city?",
						"Can you tell me your location?"
				};
				Random rLocation = new Random();        
		      	int randomNumberLocation = rLocation.nextInt(locationQuestionDictionary.length);
		      	response = locationQuestionDictionary[randomNumberLocation];
		      	//===== "Method modified for Response Generation assignment" Ends ===== 
            break;
            	
            //Dialogue States in the Weather domain  
            
        	case "ANSWER-WEATHER":
        		//===== "Method modified for Response Generation assignment" Begins =====
        		//Example 4: Use the extracted slot value in responses
        		String nowLocation = getLatestSlotValueByKey("Location", slotHistory);
        		response = "Today's weather forecast at "+nowLocation+" is: [WEATHER REPORT]";
        		//===== "Method modified for Response Generation assignment" Ends ===== 
            break;
            
        	case "ANSWER-SNOW":
        		response = "Today will snow [REPORT]";
            break;
            
        	case "ANSWER-RAIN":
        		response = "Today will rain [REPORT]";
            break;
            
            //Dialogue States in the Food domain
            
        	case "ANSWER-FIND-FOOD":
        		response = "You can find food at [ANSWER-FIND-FOOD]";
            break;
            
        	case "ASK-FOOD-TYPE":
        		response = "What do you want to eat?";
            break;
            
            /*
        	case "ASK-LOCATION-ORDER-FOOD":
        		response = "Where do you want to order from?";
            break;
        		
        	case "ASK-LOCATION-FIND-FOOD":
        		response = "I will find some restaurants near you. Which area are you in?";
            break;
            
        	case "ANSWER-ORDER-FOOD":
        		response = "I will find some restaurants near you. Which area are you in?";
            break;
            
        	
        	*/
        	
        	default:
        		System.err.println("Invalid dialogueStateName: " + dialogueStateName);
        		System.exit(1);
        		//throw new IllegalArgumentException("Invalid dialogueStateName: " + dialogueStateName);
        		
		}
		
		return response;
		
	}
	
	private static String getLatestSlotValueByKey(String key, List<Hashtable<String, String>> slotHistory) {
		String result = "";
		for(Hashtable<String, String> nowSlotValues: slotHistory) {
			if(nowSlotValues.get(key)!=null) {
				if(nowSlotValues.get(key).length()>0) {
					result = nowSlotValues.get(key);
				}
			}
		}
		return result;
	}


	private static String getChitChatResponse(String nowInputText) {
		String nowResponse = "[CHIT-CHAT RESPONSE]";
		if(nowInputText.toUpperCase().contains("HOW ARE YOU")) {
			nowResponse = "I'm good. How about you?";
		}else if(nowInputText.toUpperCase().contains("WHAT'S YOUR NAME")){
			nowResponse = "I am TaskBot. How about you?";
		}
		return nowResponse;
	}
	
	
	
}
